import pygame

import QT
from object_3d import *
from camera import *
from projection import *
import pygame as pg
from QT import *
from SQL import *


USER_NAME = "Guest"


class SoftwareRender:
    def __init__(self):
        pg.init()
        self.RES = self.WIDTH, self.HEIGHT = 1600, 1200
        self.H_WIDTH, self.H_HEIGHT = self.WIDTH // 2, self.HEIGHT // 2
        self.FPS = 60
        self.screen = pg.display.set_mode(self.RES, pygame.RESIZABLE)
        self.clock = pg.time.Clock()
        self.object_list = []
        self.map_objects = []
        self.create_objects()

    # создаются объекты 3D моделей:
    def create_objects(self):
        self.camera = Camera(self, [0, 0, 0])
        self.projection = Projection(self)
        for i in range(len(QT.MY_QT_LIST)):
            get_file("Новая БД", USER_NAME, QT.MY_QT_LIST[i])
            self.map_objects.append(i)
            setattr(self, f"Object_{i}", self.get_object_from_file("my_file.obj"))

    # файл obj преобразуется в объект python:
    def get_object_from_file(self, filename):
        vertex, faces = [], []
        with open(filename) as f:
            for line in f:
                if line.startswith('v '):
                    vertex.append([float(i) for i in line.split()[1:]] + [1])
                elif line.startswith('f'):
                    faces_ = line.split()[1:]
                    faces.append([int(face_.split('/')[0]) - 1 for face_ in faces_])
        return Object3D(self, vertex, faces)

    # отрисовка:
    def draw(self):
        self.screen.fill(pg.Color('darkslategray'))
        for i in self.map_objects:
            getattr(self, f"Object_{i}").draw()

    # цикл отрисовки:
    def run(self):
        pg.init()
        p = False
        while not p:
            self.draw()
            p = self.camera.control()
            k = [None for i in pg.event.get() if i.type == pg.QUIT]
            pg.display.set_caption(str(self.clock.get_fps()))
            pg.display.flip()
            self.clock.tick(self.FPS)
        pygame.quit()


if __name__ == '__main__':
    start()
