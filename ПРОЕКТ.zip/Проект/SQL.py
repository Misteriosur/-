import sqlite3
import os
import sys


def convert_to_binary_data(filename):
    # Преобразование данных в двоичный формат
    with open(filename, 'rb') as file:
        blob_data = file.read()
    return blob_data


def convert_of_binary_data(filename, read_file):
    # Преобразование данных в двоичный формат
    with open(filename, 'wb+') as file:
        file.write(read_file)


def get_user_id(db_name, user_name):
    con = sqlite3.connect(str(db_name))
    cursor = con.cursor()
    cursor.execute(f"""UPDATE Files_id SET count = count + 1 WHERE
     name='{str(user_name)}'""").fetchall()
    con.commit()
    result = cursor.execute(f"""SELECT count FROM Files_id WHERE
     name='{str(user_name)}'""").fetchall()
    if result:
        return result[0][0]
    return


def new_user(db_name, user_name, password):
    con = sqlite3.connect(str(db_name))
    cursor = con.cursor()
    cursor.execute(f"""INSERT INTO Users(name,password)
     VALUES('{user_name}','{password}')""").fetchall()
    cursor.execute(f"""INSERT INTO Files_id(name,count)
     VALUES('{user_name}','{-1}')""").fetchall()
    con.commit()


def del_user(db_name, user_name):
    con = sqlite3.connect(str(db_name))
    cursor = con.cursor()
    cursor.execute(f"""DELETE FROM Users Where name='{user_name}'""").fetchall()
    result = cursor.execute(f"""SELECT * FROM Users""").fetchall()
    con.commit()


def del_file(db_name, user_name, id):
    con = sqlite3.connect(str(db_name))
    cursor = con.cursor()
    cursor.execute(f"""DELETE FROM Files
     Where name='{user_name}' AND id={id}""").fetchall()
    cursor.execute(f"""UPDATE Files_id SET count = count - 1 Where name='{user_name}'""").fetchall()
    for i in range(get_len_links("Новая БД", user_name)):
        if i > id:
            cursor.execute(f"""UPDATE Files SET id = id - 1 Where name='{user_name}' AND id={i}""")
    con.commit()


def clear_user_files(db_name, user_name):
    con = sqlite3.connect(str(db_name))
    cursor = con.cursor()
    cursor.execute(f"""DELETE FROM Files Where name='{user_name}'""").fetchall()
    cursor.execute(f"""UPDATE Files_id SET count = -1 Where name='{user_name}'""").fetchall()
    con.commit()


def returned_password(db_name, user_name):
    con = sqlite3.connect(str(db_name))
    cursor = con.cursor()
    result = cursor.execute(f"""SELECT * FROM Users WHERE name='{str(user_name)}'""").fetchall()
    if result:
        return False, result[0][1]
    else:
        return True, None


def new_file(db_name, user_name, file_name, file_link):
    con = sqlite3.connect(str(db_name))
    cursor = con.cursor()
    if os.path.isfile('my_file.obj'):
        os.remove("my_file.obj")
    with open(file_link) as file, open("my_file.obj", "a+") as file_2:
        data = file.readlines()
        for line in range(len(data)):
            if data[line].startswith('#'):
                pass
            else:
                file_2.write(data[line])

    data = convert_to_binary_data("my_file.obj")

    sqlite_insert_blob_query = """INSERT INTO Files
                                      (name, file_name, file,
                                       id) VALUES (?, ?, ?, ?)"""
    data_tuple = (str(user_name), str(file_name), data,
                  get_user_id("Новая БД", str(user_name)))
    cursor.execute(sqlite_insert_blob_query, data_tuple)
    con.commit()


def get_file(db_name, user_name, id):
    con = sqlite3.connect(str(db_name))
    cursor = con.cursor()
    result = cursor.execute(f"""SELECT file FROM Files WHERE
     name='{str(user_name)}' AND id={id}""").fetchall()
    if result:
        result = result[0][0]
        convert_of_binary_data("my_file.obj", result)


def get_file_name(db_name, user_name, id):
    con = sqlite3.connect(str(db_name))
    cursor = con.cursor()
    result = cursor.execute(f"""SELECT file_name FROM Files WHERE
     name='{str(user_name)}' and id={id}""").fetchall()
    if result:
        return result[0][0]
    return


def get_len_links(db_name, user_name):
    con = sqlite3.connect(str(db_name))
    cursor = con.cursor()
    result = cursor.execute(f"""SELECT count FROM Files_id
     WHERE name='{str(user_name)}'""").fetchall()
    if result:
        result = result[0][0] + 1
        return result
    return 0
