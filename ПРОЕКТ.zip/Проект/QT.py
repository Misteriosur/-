from PyQt5 import QtCore, QtGui, QtWidgets
import main
from main import SoftwareRender
from PyQt5.QtWidgets import QWidget
from PyQt5.QtWidgets import QFileDialog
from SQL import *
import os
import sys
from PyQt5 import QtCore, QtGui, QtWidgets


MY_QT_LIST = []
QT_FILE_NAME = ""


class Ui_Widget(object):
    def setupUi(self, Widget):
        Widget.setObjectName("Widget")
        Widget.resize(606, 596)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Preferred,
                                           QtWidgets.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(Widget.sizePolicy().hasHeightForWidth())
        Widget.setSizePolicy(sizePolicy)
        Widget.setFixedSize(QtCore.QSize(606, 596))
        Widget.setStyleSheet("")
        Widget.setStyleSheet("background-color: rgb(100, 133, 202);")
        self.tab_1 = QtWidgets.QTabWidget(Widget)
        self.tab_1.setGeometry(QtCore.QRect(9, 9, 588, 578))
        self.tab_1.setObjectName("tab_1")
        self.tab = QtWidgets.QWidget()
        self.tab.setObjectName("tab")
        self.gridLayout_3 = QtWidgets.QGridLayout(self.tab)
        self.gridLayout_3.setObjectName("gridLayout_3")
        self.account = QtWidgets.QLabel(self.tab)
        self.account.setObjectName("account")
        self.gridLayout_3.addWidget(self.account, 0, 4, 1, 1)
        spacerItem = QtWidgets.QSpacerItem(40, 20,
                                           QtWidgets.QSizePolicy.Expanding,
                                           QtWidgets.QSizePolicy.Minimum)
        self.gridLayout_3.addItem(spacerItem, 3, 0, 1, 1)
        spacerItem1 = QtWidgets.QSpacerItem(20, 40,
                                            QtWidgets.QSizePolicy.Minimum,
                                            QtWidgets.QSizePolicy.Expanding)
        self.gridLayout_3.addItem(spacerItem1, 8, 1, 1, 1)
        spacerItem2 = QtWidgets.QSpacerItem(20, 40,
                                            QtWidgets.QSizePolicy.Minimum,
                                            QtWidgets.QSizePolicy.Expanding)
        self.gridLayout_3.addItem(spacerItem2, 7, 1, 1, 1)
        self.autorisation_name = QtWidgets.QLineEdit(self.tab)
        self.autorisation_name.setMaximumSize(QtCore.QSize(125, 24))
        self.autorisation_name.setObjectName("autorisation_name")
        self.gridLayout_3.addWidget(self.autorisation_name, 2, 1, 1, 1)
        self.label_1 = QtWidgets.QLabel(self.tab)
        self.label_1.setObjectName("label_1")
        self.gridLayout_3.addWidget(self.label_1, 1, 1, 1, 1)
        self.label_2 = QtWidgets.QLabel(self.tab)
        self.label_2.setObjectName("label_2")
        self.gridLayout_3.addWidget(self.label_2, 3, 1, 1, 1)
        self.autorisatio_info_2 = QtWidgets.QLabel(self.tab)
        self.autorisatio_info_2.setText("")
        self.autorisatio_info_2.setObjectName("autorisatio_info_2")
        self.gridLayout_3.addWidget(self.autorisatio_info_2, 4, 2, 1, 4)
        self.autorisation_button = QtWidgets.QPushButton(self.tab)
        self.autorisation_button.setMaximumSize(QtCore.QSize(125, 24))
        self.autorisation_button.setObjectName("autorisation_button")
        self.gridLayout_3.addWidget(self.autorisation_button, 5, 1, 1, 1)
        self.autorisation_password = QtWidgets.QLineEdit(self.tab)
        self.autorisation_password.setMaximumSize(QtCore.QSize(125, 24))
        self.autorisation_password.setObjectName("autorisation_password")
        self.gridLayout_3.addWidget(self.autorisation_password, 4, 1, 1, 1)
        spacerItem3 = QtWidgets.QSpacerItem(20, 40,
                                            QtWidgets.QSizePolicy.Minimum,
                                            QtWidgets.QSizePolicy.Expanding)
        self.gridLayout_3.addItem(spacerItem3, 0, 1, 1, 1)
        self.mode_button = QtWidgets.QRadioButton(self.tab)
        self.mode_button.setObjectName("mode_button")
        self.gridLayout_3.addWidget(self.mode_button, 5, 2, 1, 2)
        self.account_name = QtWidgets.QLabel(self.tab)
        self.account_name.setObjectName("account_name")
        self.gridLayout_3.addWidget(self.account_name, 0, 5, 1, 1)
        self.autorisatio_info = QtWidgets.QLabel(self.tab)
        self.autorisatio_info.setText("")
        self.autorisatio_info.setObjectName("autorisatio_info")
        self.gridLayout_3.addWidget(self.autorisatio_info, 2, 2, 1, 4)
        self.exit = QtWidgets.QPushButton(self.tab)
        self.exit.setMaximumSize(QtCore.QSize(125, 24))
        self.exit.setObjectName("exit")
        self.gridLayout_3.addWidget(self.exit, 6, 1, 1, 1)
        self.tab_1.addTab(self.tab, "")
        self.tab_2 = QtWidgets.QWidget()
        self.tab_2.setObjectName("tab_2")
        self.gridLayout_2 = QtWidgets.QGridLayout(self.tab_2)
        self.gridLayout_2.setObjectName("gridLayout_2")
        self.listWidget = QtWidgets.QListWidget(self.tab_2)
        self.listWidget.setObjectName("listWidget")
        self.gridLayout_2.addWidget(self.listWidget, 6, 0, 1, 1)
        self.delete_button = QtWidgets.QPushButton(self.tab_2)
        self.delete_button.setObjectName("delete_button")
        self.gridLayout_2.addWidget(self.delete_button, 3, 0, 1, 1)
        self.label = QtWidgets.QLabel(self.tab_2)
        self.label.setObjectName("label")
        self.gridLayout_2.addWidget(self.label, 5, 0, 1, 1)
        self.label34 = QtWidgets.QLabel(self.tab_2)
        self.label34.setObjectName("label34")
        self.gridLayout_2.addWidget(self.label34, 5, 2, 1, 1)
        self.clear_button = QtWidgets.QPushButton(self.tab_2)
        self.clear_button.setObjectName("clear_button")
        self.gridLayout_2.addWidget(self.clear_button, 8, 0, 1, 4)
        self.verticalLayout_3 = QtWidgets.QVBoxLayout()
        self.verticalLayout_3.setObjectName("verticalLayout_3")
        spacerItem4 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum,
                                            QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_3.addItem(spacerItem4)
        self.get = QtWidgets.QPushButton(self.tab_2)
        self.get.setObjectName("get")
        self.verticalLayout_3.addWidget(self.get)
        self.un_get = QtWidgets.QPushButton(self.tab_2)
        self.un_get.setObjectName("un_get")
        self.verticalLayout_3.addWidget(self.un_get)
        spacerItem5 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum,
                                            QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_3.addItem(spacerItem5)
        self.gridLayout_2.addLayout(self.verticalLayout_3, 6, 1, 1, 1)
        self.list_object = QtWidgets.QListWidget(self.tab_2)
        self.list_object.setObjectName("list_object")
        self.gridLayout_2.addWidget(self.list_object, 6, 2, 1, 1)
        self.add_object_button = QtWidgets.QPushButton(self.tab_2)
        self.add_object_button.setObjectName("add_object_button")
        self.gridLayout_2.addWidget(self.add_object_button, 1, 0, 1, 1)
        self.start_button = QtWidgets.QPushButton(self.tab_2)
        self.start_button.setMinimumSize(QtCore.QSize(339, 24))
        self.start_button.setMaximumSize(QtCore.QSize(339, 24))
        self.start_button.setObjectName("start_button")
        self.gridLayout_2.addWidget(self.start_button, 3, 2, 1, 1)
        self.tab_1.addTab(self.tab_2, "")
        self.tab_3 = QtWidgets.QWidget()
        self.tab_3.setObjectName("tab_3")
        self.gridLayout_4 = QtWidgets.QGridLayout(self.tab_3)
        self.gridLayout_4.setObjectName("gridLayout_4")
        self.label_6 = QtWidgets.QLabel(self.tab_3)
        font = QtGui.QFont()
        font.setPointSize(9)
        self.label_6.setFont(font)
        self.label_6.setObjectName("label_6")
        self.gridLayout_4.addWidget(self.label_6, 0, 0, 1, 1)
        self.tab_1.addTab(self.tab_3, "")

        self.retranslateUi(Widget)
        self.tab_1.setCurrentIndex(0)
        QtCore.QMetaObject.connectSlotsByName(Widget)

    def retranslateUi(self, Widget):
        _translate = QtCore.QCoreApplication.translate
        Widget.setWindowTitle(_translate("Widget", "Widget"))
        self.account.setText(_translate("Widget", "Аккаунт:"))
        self.label_1.setText(_translate("Widget", "Логин:"))
        self.label_2.setText(_translate("Widget", "Пароль:"))
        self.autorisation_button.setText(_translate("Widget", "Войти"))
        self.mode_button.setText(_translate("Widget", "Новый аккаунт"))
        self.account_name.setText(_translate("Widget", "Guest"))
        self.exit.setText(_translate("Widget", "Выйти"))
        self.tab_1.setTabText(self.tab_1.indexOf(self.tab), _translate("Widget",
                                                                       "Регистратура"))
        self.delete_button.setText(_translate("Widget", "Удалить объект"))
        self.label.setText(_translate("Widget", "Все:"))
        self.label34.setText(_translate("Widget", "Отображаемые:"))
        self.clear_button.setText(_translate("Widget", "Очистить"))
        self.get.setText(_translate("Widget", ">"))
        self.un_get.setText(_translate("Widget", "<"))
        self.add_object_button.setText(_translate("Widget", "Добавить файл"))
        self.start_button.setText(_translate("Widget", "Отобразить"))
        self.tab_1.setTabText(self.tab_1.indexOf(self.tab_2), _translate("Widget",
                                                                         "Отображатель"))
        with open("текст.txt") as file:
            self.label_6.setText(_translate("Widget", file.read()))
        self.tab_1.setTabText(self.tab_1.indexOf(self.tab_3), _translate("Widget",
                                                                         "Информаторий"))


class My_window(Ui_Widget, QWidget):
    def setupUi(self, Widget):
        super(My_window, self).setupUi(Widget)
        self.link_object_list = []
        f = []
        if os.path.isfile('link_list.txt'):
            with open("link_list.txt", "r") as link_list:
                f = link_list.readlines()
        self.len_list = len(f)

    def window_func(self):
        self.start_button.clicked.connect(self.start)
        self.add_object_button.clicked.connect(self.my_file)
        self.clear_button.clicked.connect(self.clear_file)
        self.autorisation_button.clicked.connect(self.autorisation)
        self.delete_button.clicked.connect(self.delete_file)
        self.get.clicked.connect(self.geter)
        self.un_get.clicked.connect(self.un_geter)
        self.exit.clicked.connect(self.exit_account)

    def start(self):
        self.my_app = SoftwareRender()
        self.my_app.run()

    def my_file(self):
        self.fname = QFileDialog.getOpenFileName(self, 'Выбрать модель',
                                                 '', 'Модель (*.obj);')[0]
        f = self.fname
        f = f
        if f != "":
            test = f.split("/")
            if "." not in test[len(test) - 1]:
                return
            else:
                if test[len(test) - 1].split(".")[1] != "obj" or main.USER_NAME == "Guest":
                    return
                else:
                    self.get_file_name()
                    new_file("Новая БД", self.account_name.text(), QT_FILE_NAME, f)
                    self.listWidget.addItem(
                        f"""{get_len_links("Новая БД",
                                           self.get_account_name()) - 1}id {QT_FILE_NAME}""")
                    self.len_list += 1

    def get_file_name(self):
        global QT_FILE_NAME
        name, ok_pressed = QtWidgets.QInputDialog.getText(self, "Введите имя файла",
                                                          "Какое имя вы выберите?")
        if ok_pressed:
            QT_FILE_NAME = name

    def clear_file(self):
        self.len_list = 0
        self.listWidget.clear()
        self.list_object.clear()
        clear_user_files("Новая БД", main.USER_NAME)

    def delete_file(self):
        a = self.listWidget.takeItem(self.listWidget.currentRow())
        if a:
            del_file("Новая БД", main.USER_NAME, int(a.text().split("id ")[0]))

    def registration(self):
        name = self.autorisation_name.text()
        password = self.autorisation_password.text()
        if name and name != "Guest":
            if password:
                if "123" not in password and "qwerty" not in password:
                    if len(password) >= 7:
                        if returned_password("Новая БД", name)[0]:
                            self.autorisatio_info.setText("Регистрация прошла успешно!")
                            new_user("Новая БД", name, password)
                            self.set_account(name)
                        else:
                            self.autorisatio_info.setText("Такой пользователь уже существует")
                    else:
                        self.autorisatio_info_2.setText("Пароль должен быть больше 7 символов")
                else:
                    self.autorisatio_info_2.setText("Придумайте более сложный пароль")
            else:
                self.autorisatio_info_2.setText("Введите пароль")
        else:
            self.autorisatio_info.setText("Введите имя")

    def autorisation(self):
        self.autorisatio_info.setText("")
        self.autorisatio_info_2.setText("")
        if self.mode_button.isChecked():
            self.registration()
        else:
            name = self.autorisation_name.text()
            password = self.autorisation_password.text()
            if name:
                if password:
                    test = returned_password("Новая БД", name)[0]
                    realy_password = returned_password("Новая БД", name)[1]
                    if not test:
                        if password == realy_password:
                            self.autorisatio_info.setText("Авторизация прошла успешно!")
                            self.set_account(name)
                        else:
                            self.autorisatio_info_2.setText("Неверный пароль!")
                    else:
                        self.autorisatio_info.setText("Такой пользователь не существует!")
                else:
                    self.autorisatio_info_2.setText("Введите пароль")
            else:
                self.autorisatio_info.setText("Введите имя")

    def set_account(self, name):
        global AUTO_USER
        self.account_name.setText(name)
        main.USER_NAME = name
        self.autorisation_name.setText("")
        self.autorisation_password.setText("")
        self.listWidget.clear()
        self.list_object.clear()
        for i in range(get_len_links("Новая БД", main.USER_NAME)):
            self.listWidget.addItem(f"""{i}id {get_file_name("Новая БД",
                                                             main.USER_NAME, i)}""")
        self.get_view()

    def exit_account(self):
        self.account_name.setText("Guest")
        self.autorisatio_info.setText("")
        self.autorisatio_info_2.setText("")
        main.USER_NAME = "Guest"
        self.autorisation_name.setText("")
        self.autorisation_password.setText("")
        self.listWidget.clear()
        self.list_object.clear()

    def get_account_name(self):
        return self.account_name.text()

    def get_view(self):
        MY_QT_LIST.clear()
        for i in range(len(self.list_object)):
            MY_QT_LIST.append(self.list_object.item(i).text().split("id ")[0])

    def geter(self):
        if self.listWidget.selectedItems():
            self.list_object.addItem(self.listWidget.selectedItems()[0].text())
            self.listWidget.takeItem(self.listWidget.currentRow())
        self.get_view()

    def un_geter(self):
        if self.list_object.selectedItems():
            self.listWidget.addItem(self.list_object.selectedItems()[0].text())
            self.list_object.takeItem(self.list_object.currentRow())
        self.get_view()


def start():
    app = QtWidgets.QApplication(sys.argv)
    Widget = QtWidgets.QWidget()
    ui = My_window()
    ui.setupUi(Widget)
    ui.window_func()
    Widget.show()
    sys.exit(app.exec_())
